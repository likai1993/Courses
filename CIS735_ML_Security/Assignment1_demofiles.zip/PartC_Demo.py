import pandas as pd
import itertools
import numpy as np
users=["A","B"]

df=pd.read_csv('Features.csv')
df=df.drop(["User"],axis=1)

'''
for i in range(0,10):
    for j in range (i+1,10):
'''

a = df.iloc[0].tolist()
b = df.iloc[1].tolist()
print (sum((p-q)**2 for p, q in zip(a, b)) ** .5)


'''from scipy.spatial.distance import pdist
#print(pdist(df.values, 'euclid'))
'''

